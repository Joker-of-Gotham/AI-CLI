# Gemini CLI A2A服务器

## 此包中的所有代码都是实验性的，正在积极开发中

此包包含Gemini CLI的A2A服务器实现。